package entities;

import java.util.Scanner;
import entities.Account;
import entities.Customer;
import entities.SavingAccount;
import entities.CurrentAccount;
import entities.Bank;

public class Main {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		Bank bank = new Bank();

		while (true) {
			System.out.println("===Bank Menu===");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.View balance");
			System.out.println("5.Display account details");
			System.out.println("6.Exit");

			System.out.println("enter choice:");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Customer ID:");
				int id = sc.nextInt();
				sc.nextLine();

				System.out.println("Enter Customer Name");
				String name = sc.nextLine();

				System.out.println("Enter Phone Number");
				String phone = sc.nextLine();

				System.out.println("Enter Address");
				String address = sc.nextLine();

				Customer customer = new Customer(id, name, phone, address);

				System.out.println("Enter Account Number:");
				String accountNumber = sc.next();
				System.out.println("Enter Initial Balance");
				double balance = sc.nextDouble();

				System.out.println("1.Saving Account");
				System.out.println("2. Current Account");
				System.out.println("Choose Account Type");

				int type = sc.nextInt();
				Account account;
				if (type == 1) {

					account = new SavingAccount(accountNumber, balance, customer);

				} else {

					account = new CurrentAccount(accountNumber, balance, customer);

				}
				bank.createAccount(account);
				break;

			case 2:
				System.out.println("Enter Account Number:");
				accountNumber = sc.next();

				System.out.println("Enter Amount:");
				double deposit = sc.nextDouble();

				bank.depositMoney(accountNumber, deposit);
				break;

			case 3:
				System.out.println("Enter Account Number:");
				accountNumber = sc.next();

				System.out.println("Enter Amount:");
				double withdraw = sc.nextDouble();

				bank.withdrawMoney(accountNumber, withdraw);
				break;

			case 4:
				System.out.println("Enter Account Number");
				accountNumber = sc.next();
				bank.showBalance(accountNumber);
				break;

			case 5:
				System.out.println("Enter Account Number");
				accountNumber = sc.next();
				bank.displayAccount(accountNumber);
				break;
			case 6:

                System.out.println("Thank You!");

                sc.close();
                System.exit(0);

            default:

                System.out.println("Invalid Choice.");

			}
		}
	}
}