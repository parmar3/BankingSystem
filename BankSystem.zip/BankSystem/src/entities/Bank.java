package entities;
import java.util.ArrayList;
import entities.Account;
import entities.Customer;
import entities.SavingAccount;
import entities.CurrentAccount;

public class Bank {
	private ArrayList<Account>accounts=new ArrayList<>();
	public void createAccount(Account account)
	{
		accounts.add(account);
		System.out.println("Account created successfully.");
	}
	
	public Account searchAccount(String accountNumber)
	{
		for(Account account:accounts)
		{
			if(account.getAccountNumber().equals(accountNumber))
			{
				return account;
			}
		}return null;
	}
	
	public void depositMoney(String accountNumber,double amount)
	{
		Account account=searchAccount(accountNumber);
		if(account!=null)
		{
			account.deposit(amount);
		}else
		{
			System.out.println("Account not found.");
			
		}
		
	}
	
	public void withdrawMoney(String accountNumber,double amount)
	{
		Account account=searchAccount(accountNumber);
		if(account!=null)
		{
			account.withdraw(amount);
			
			
		}else {
			System.out.println("Account not found.");
			
		}
	}
		public void showBalance(String accountNumber)
		{
			Account account=searchAccount(accountNumber);
			if(account!=null)
			{
				System.out.println("Current balance : rs."+account.getBalance());
			}else
			{
				System.out.println("Account not found.");
				
			}
		}
		
		public void displayAccount(String accountNumber)
		{
			Account account=searchAccount(accountNumber);
			if(account!=null)
			{
				account.displayAccountDetails();
			}else
			{
				System.out.println("Account Not found.");
			}
		}
	}

