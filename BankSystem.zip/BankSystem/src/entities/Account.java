package entities;

public abstract class Account {
	private String accountNumber;
	  protected double balance;
	private Customer customer;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Account() {
		super();
	}

	public Account(String accountNumber, double balance,Customer customer) {
		super();
		this.accountNumber = accountNumber;

		this.balance = balance;
		this.customer=customer;

	}

	public void deposit(double amount) {
		if (amount > 0) {
			balance += amount;
			System.out.println("Successfuly deposit amount");
		} else {
			System.out.println("Invalid amount");
		}
	}

	public abstract void withdraw(double amount);

	public void displayAccountDetails() {
		customer.displayCustomer();
		System.out.println("Account number:" + accountNumber);
		System.out.println("Balance: Rs. " + balance);
	}
}
