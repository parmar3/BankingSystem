package entities;

public class CurrentAccount extends Account{
	private double overdraftLimit=2000;

	public CurrentAccount() {
		super();
		
	}

	public CurrentAccount(String accountNumber, double balance, Customer customer) {
		super(accountNumber, balance, customer);
		
	}

	public double getOverdraftLimit() {
		return overdraftLimit;
	}

	public void setOverdraftLimit(double overdraftLimit) {
		this.overdraftLimit = overdraftLimit;
	}
	
	@Override
	public void withdraw(double amount) 
	{
		if(amount<=balance+overdraftLimit)
		{
			balance-=amount;
			System.out.println("Withdraw successful.");
			
		}else
		{
			System.out.println("Overdraft limit exceeded.");
		}
	}
	
}
