package entities;

public class SavingAccount extends Account {
	private double minimumBalance = 500;
	
	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	public SavingAccount(String accountNumber, double balance, Customer customer) {
		super(accountNumber, balance, customer);

	}

	@Override
	public void withdraw(double amount) {
		if (amount <= 0) {
			System.out.println("Invalid amount");
		} else if (balance - amount >= minimumBalance) {
			balance -= amount;
			System.out.println("withdraw successful.");

		} else {
			System.out.println("Minimum balace should be maintained");
		}
	}

}
